/**
 * Shared tool plumbing: registration wrapper, per-tool cost estimators (read by the cost guard),
 * error redaction, and compact LLM-facing previews wrapped as untrusted data (G1).
 */
import type { ExtensionAPI, ExtensionContext, Theme, ToolDefinition, ToolResult } from "@earendil-works/pi-coding-agent";
import { Text } from "@earendil-works/pi-tui";
import { errorMessage } from "../../core/errors";
import { companyLine, personLine, type CompanySummary, type PersonSummary } from "../../core/fiber/entities";
import type { Estimate } from "../../core/fiber/ops";
import { asUntrusted } from "../../core/grounding";
import { redactText } from "../../core/redact";
import type { ItemRow } from "../../core/store/db";
import { localTime } from "../../core/time";
import type { Runtime } from "../runtime";
import { textTable } from "../ui/text";

export type Estimator = (input: Record<string, any>, rt: Runtime, toolCallId: string) => Promise<Estimate | undefined> | Estimate | undefined;

/** tool name → estimator. `undefined` result = free. Tools without an entry are free. */
export const ESTIMATORS = new Map<string, Estimator>();
/** Tools that are available in the "lite" tools profile (small/local models — A11, I3). */
export const LITE_TOOLS = new Set<string>();
export const SAILOR_TOOLS = new Set<string>();

export interface SailorToolDef<P> {
  name: string;
  label: string;
  description: string;
  parameters: unknown;
  lite?: boolean;
  estimate?: Estimator;
  needsKey?: boolean;
  execute: (params: P, ctx: ExtensionContext, extra: { toolCallId: string; signal?: AbortSignal; onUpdate?: (text: string) => void }) => Promise<ToolResult>;
  renderCall?: ToolDefinition<P>["renderCall"];
  renderResult?: ToolDefinition<P>["renderResult"];
}

export function registerSailorTool<P = any>(pi: ExtensionAPI, rt: Runtime, def: SailorToolDef<P>): void {
  SAILOR_TOOLS.add(def.name);
  if (def.lite) LITE_TOOLS.add(def.name);
  if (def.estimate) ESTIMATORS.set(def.name, def.estimate);
  pi.registerTool<P>({
    name: def.name,
    label: def.label,
    description: def.description,
    parameters: def.parameters,
    async execute(toolCallId, params, signal, onUpdate, ctx) {
      try {
        rt.init(ctx);
        if (def.needsKey !== false && !rt.hasKey) throw new Error("Fiber is not connected. Ask the user to run /fiber login (or set FIBER_API_KEY).");
        const res = await def.execute(params, ctx, {
          toolCallId, signal,
          onUpdate: onUpdate ? (text) => onUpdate({ content: [{ type: "text", text }] }) : undefined,
        });
        return res;
      } catch (err) {
        throw new Error(redactText(errorMessage(err)));
      } finally {
        rt.plans.delete(toolCallId);
        rt.meter.render();
      }
    },
    renderCall: def.renderCall ?? ((args: any, theme: Theme) => new Text(theme.fg("toolTitle", theme.bold(`${def.label} `)) + theme.fg("muted", summarizeArgs(args)), 0, 0)),
    renderResult: def.renderResult ?? ((result, { expanded }, theme) => {
      const t = result.content?.[0]?.type === "text" ? result.content[0].text : "";
      const plain = t.replace(/<\/?untrusted[^>]*>\n?/g, "");
      const lines = plain.split("\n");
      const shown = expanded ? lines : lines.slice(0, 14);
      return new Text(shown.join("\n") + (!expanded && lines.length > 14 ? theme.fg("dim", `\n… ${lines.length - 14} more lines (expand to see)`) : ""), 0, 0);
    }),
  });
}

export function summarizeArgs(args: Record<string, unknown> | undefined): string {
  if (!args) return "";
  return Object.entries(args)
    .filter(([, v]) => v !== undefined && v !== null && v !== "")
    .map(([k, v]) => `${k}=${typeof v === "object" ? JSON.stringify(v).slice(0, 60) : String(v).slice(0, 60)}`)
    .join(" ")
    .slice(0, 160);
}

export function ok(text: string, details?: unknown): ToolResult {
  return { content: [{ type: "text", text }], details };
}

export function peoplePreview(rows: PersonSummary[], limit = 10): string {
  if (!rows.length) return "(no results)";
  const table = textTable(["#", "Name", "Title", "Company", "Location", "LinkedIn"], rows.slice(0, limit).map((p, i) => [i + 1, p.name, p.title, p.company, p.location, p.linkedinUrl?.replace("https://www.linkedin.com", "")]));
  return asUntrusted("fiber", table) + (rows.length > limit ? `\n… ${rows.length - limit} more in the list` : "");
}

export function companiesPreview(rows: CompanySummary[], limit = 10): string {
  if (!rows.length) return "(no results)";
  const table = textTable(["#", "Company", "Domain", "Industry", "Emp", "HQ", "Latest funding"], rows.slice(0, limit).map((c, i) => [i + 1, c.name, c.domain, c.industry, c.headcount, c.hq, c.latestFunding ? `${c.latestFunding.stage ?? ""} ${c.latestFunding.date?.slice(0, 7) ?? ""}`.trim() : ""]));
  return asUntrusted("fiber", table) + (rows.length > limit ? `\n… ${rows.length - limit} more in the list` : "");
}

export function itemsTable(kind: "people" | "companies", items: ItemRow[], fields?: string[]): string {
  if (kind === "people") {
    const cols = fields?.length ? fields : ["id", "name", "title", "company", "email", "status"];
    const get = (it: ItemRow, f: string): unknown => {
      const s: any = it.entity?.summary ?? {};
      const email = it.contacts?.find((c) => c.type === "work_email") ?? it.contacts?.find((c) => c.type === "personal_email");
      switch (f) {
        case "id": return it.entity_id;
        case "email": return email ? `${email.value}${email.validity ? ` (${email.validity})` : ""}` : "";
        case "phone": return it.contacts?.find((c) => c.type === "phone")?.value ?? "";
        case "local_time": return localTime(s.timezone) ?? "";
        case "linkedin": return it.entity?.linkedin_url ?? "";
        case "status": return it.status;
        case "notes": return (it.notes ?? "").slice(0, 80);
        case "funding": return "";
        default: return typeof s[f] === "object" ? JSON.stringify(s[f]) : s[f] ?? (it.entity as any)?.[f] ?? "";
      }
    };
    return asUntrusted("fiber", textTable(cols, items.map((it) => cols.map((c) => get(it, c) as any))));
  }
  const cols = fields?.length ? fields : ["id", "name", "domain", "industry", "headcount", "latestFunding", "status"];
  const get = (it: ItemRow, f: string): unknown => {
    const s: any = it.entity?.summary ?? {};
    if (f === "id") return it.entity_id;
    if (f === "status") return it.status;
    if (f === "notes") return (it.notes ?? "").slice(0, 80);
    if (f === "latestFunding") return s.latestFunding ? `${s.latestFunding.stage ?? ""} ${s.latestFunding.date?.slice(0, 7) ?? ""}` : "";
    return typeof s[f] === "object" ? JSON.stringify(s[f]) : s[f] ?? "";
  };
  return asUntrusted("fiber", textTable(cols, items.map((it) => cols.map((c) => get(it, c) as any))));
}

export { personLine, companyLine };
